import React from 'react'

const ContactSupport = () => {
  return (
    <div className='Contact-Support'>
        Contact Support
    </div>
  )
}

export default ContactSupport
