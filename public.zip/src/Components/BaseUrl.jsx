// BaseUrl.jsx
export const BaseUrl = "http://localhost:3000";
// export const BaseUrl = "http://195.250.30.251:3000";
// export const BaseUrl = "https://dklean-backend-2fg0.onrender.com";
