import React from 'react'

const Pharmacy = () => {
  return (
    <div className='Pharmacy'>
      Pharmacy
    </div>
  )
}

export default Pharmacy
